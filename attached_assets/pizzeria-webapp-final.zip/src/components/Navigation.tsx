import { ShoppingCart, Pizza } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCartStore } from '../store/cart';

export default function Navigation() {
  const items = useCartStore((state) => state.items);
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <nav className="fixed top-0 left-0 right-0 bg-white shadow-md z-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Pizza className="h-8 w-8 text-[#6BA368]" />
            <span className="font-bold text-xl">Pizzeria Janíček</span>
          </Link>
          
          <div className="flex items-center space-x-4">
            <Link to="/menu" className="text-gray-700 hover:text-[#6BA368]">
              Menu
            </Link>
            <Link
              to="/checkout"
              className="relative inline-flex items-center p-2"
            >
              <ShoppingCart className="h-6 w-6 text-[#6BA368]" />
              {itemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {itemCount}
                </span>
              )}
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
import { useState } from "react";
import { motion } from "framer-motion";
import { useCartStore } from "../store/cart";
import { Link } from "react-router-dom";
import { ArrowLeft, Plus, Minus } from "lucide-react";

export default function Checkout() {
  const cart = useCartStore((state) => state.items);
  const clearCart = useCartStore((state) => state.clearCart);
  const updateQuantity = useCartStore((state) => state.updateQuantity);
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [note, setNote] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleQuantityChange = (id: number, newQuantity: number) => {
    if (newQuantity >= 1) {
      updateQuantity(id, newQuantity);
    }
  };

  const body = `Objednávka:\n${cart
    .map(
      (i) =>
        `• ${i.name} (${i.price} €) x ${i.quantity}${
          i.extras?.length ? " + " + i.extras.join(", ") : ""
        }`
    )
    .join("\n")}\n\nCelková suma: ${total.toFixed(
    2
  )} €\n\nMeno: ${name}\nAdresa/Odber: ${address}\nPoznámka: ${note}`;

  const mailtoLink = `mailto:objednavky@pizzeria.sk?subject=Nova objednavka&body=${encodeURIComponent(
    body
  )}`;

  return (
  <motion.div 
    initial={{ opacity: 0, y: 10 }} 
    animate={{ opacity: 1, y: 0 }} 
    transition={{ duration: 0.3 }}
  >

    <div className="container mx-auto px-4 py-8">
      <section className="max-w-3xl mx-auto bg-white rounded-xl shadow-md p-6 mt-20">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-[#2e7d32]">
            Dokončenie objednávky
          </h1>
          <Link
            to="/menu"
            className="flex items-center text-[#6BA368] hover:text-[#5a915a] transition-colors"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Späť na menu
          </Link>
        </div>

        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-3">Vaša objednávka:</h2>
          {cart.length === 0 ? (
            <p className="text-gray-500">Košík je prázdny.</p>
          ) : (
            <ul className="space-y-4">
              {cart.map((item, i) => (
                <li
                  key={i}
                  className="flex flex-col sm:flex-row sm:items-center justify-between py-4 border-b"
                >
                  <div className="flex-1">
                    <span className="font-medium">{item.name}</span>
                    {item.extras.length > 0 && (
                      <div className="text-sm text-gray-500">
                        + {item.extras.join(", ")}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center mt-2 sm:mt-0">
                    <div className="flex items-center space-x-3 mr-6">
                      <button
                        onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                        className="p-1 rounded-full hover:bg-gray-100"
                      >
                        <Minus className="h-5 w-5 text-[#6BA368]" />
                      </button>
                      <span className="font-medium w-8 text-center">{item.quantity}</span>
                      <button
                        onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                        className="p-1 rounded-full hover:bg-gray-100"
                      >
                        <Plus className="h-5 w-5 text-[#6BA368]" />
                      </button>
                    </div>
                    <span className="font-medium min-w-[80px] text-right">
                      {(item.price * item.quantity).toFixed(2)} €
                    </span>
                  </div>
                </li>
              ))}
              <li className="flex justify-between items-center pt-4 font-bold text-lg">
                <span>Celková suma:</span>
                <span>{total.toFixed(2)} €</span>
              </li>
            </ul>
          )}
        </div>

        <form className="space-y-4">
          <div>
            <label htmlFor="name" className="block font-medium mb-1">
              Meno:
            </label>
            <input
              id="name" aria-label="Meno"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#6BA368]"
              required
            />
          </div>
          <div>
            <label htmlFor="address" className="block font-medium mb-1">
              Adresa alebo osobný odber:
            </label>
            <input
              id="address" aria-label="Adresa alebo osobný odber"
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#6BA368]"
              required
            />
          </div>
          <div>
            <label htmlFor="note" className="block font-medium mb-1">
              Poznámka (nepovinné):
            </label>
            <textarea
              id="note" aria-label="Poznámka"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#6BA368]"
              rows={3}
            />
          </div>

          <div className="mt-6 flex flex-col sm:flex-row gap-4">
            <Link
              to="/menu"
              className="flex-1 inline-block text-center px-6 py-3 rounded-xl font-semibold border-2 border-[#6BA368] text-[#6BA368] hover:bg-[#6BA368] hover:text-white transition-colors"
            >
              Pridať ďalšiu pizzu
            </Link>
            <button
              type="button"
              onClick={() => { setSubmitted(true); clearCart(); setTimeout(() => { window.location.href = mailtoLink; }, 300); }
              className={`flex-1 inline-block text-center bg-[#6BA368] text-white px-6 py-3 rounded-xl font-semibold hover:bg-[#5a915a] transition disabled:opacity-50 disabled:cursor-not-allowed ${
                cart.length === 0 ? "opacity-50 cursor-not-allowed" : ""
              }`}
              disabled={cart.length === 0}
            >
              Odoslať objednávku
            </button>
          </div>
        
        {submitted && (
          <div className="mt-6 p-4 rounded-xl bg-green-50 text-green-700 border border-green-300 text-sm">
            ✅ Objednávka bola odoslaná. Ďakujeme za vašu dôveru!
          </div>
        )}

      </form>
      </section>
    </div>
  </motion.div>
  );
}
import { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { pizzaExtras } from '../data/pizzaExtras';
import { useCartStore } from '../store/cart';
import { ArrowLeft } from 'lucide-react';

const AVAILABLE_EXTRAS = [
  { id: 1, name: 'Extra syr', price: 1.5 },
  { id: 2, name: 'Šunka', price: 1.0 },
  { id: 3, name: 'Kukurica', price: 0.5 },
  { id: 4, name: 'Olivy', price: 1.0 },
];

const PIZZAS = [
  { id: 1, name: "Margherita", price: 6.90, description: "Paradajková omáčka, mozzarella, bazalka", img: "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=800&h=600&fit=crop" },
  { id: 2, name: "Šunková", price: 7.50, description: "Paradajková omáčka, mozzarella, šunka", img: "https://images.unsplash.com/photo-1593560708920-61dd98c46a4e?w=800&h=600&fit=crop" },
  { id: 3, name: "Diavola", price: 7.90, description: "Paradajková omáčka, mozzarella, pikantná saláma", img: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&h=600&fit=crop" },
  { id: 4, name: "Quattro Formaggi", price: 8.90, description: "Smotanový základ, mozzarella, gorgonzola, parmezán, ementál", img: "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=800&h=600&fit=crop" },
  { id: 5, name: "Hawai", price: 7.90, description: "Paradajková omáčka, mozzarella, šunka, ananás", img: "https://images.unsplash.com/photo-1594007654729-407eedc4be65?w=800&h=600&fit=crop" },
  { id: 6, name: "Prosciutto", price: 9.90, description: "Paradajková omáčka, mozzarella, prosciutto, rukola", img: "https://images.unsplash.com/photo-1588315029754-2dd089d39a1a?w=800&h=600&fit=crop" },
  { id: 7, name: "Vegetariánska", price: 7.90, description: "Paradajková omáčka, mozzarella, šampiňóny, paprika, cibuľa", img: "https://images.unsplash.com/photo-1511689660979-10d2b1aada49?w=800&h=600&fit=crop" },
  { id: 8, name: "Tuniaková", price: 8.50, description: "Paradajková omáčka, mozzarella, tuniak, cibuľa", img: "https://images.unsplash.com/photo-1571066811602-716837d681de?w=800&h=600&fit=crop" },
  { id: 9, name: "Capricciosa", price: 8.90, description: "Paradajková omáčka, mozzarella, šunka, šampiňóny, olivy", img: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=800&h=600&fit=crop" },
  { id: 10, name: "Carbonara", price: 8.90, description: "Smotanový základ, mozzarella, slanina, vajce, parmezán", img: "https://images.unsplash.com/photo-1585238342024-78d387f4a707?w=800&h=600&fit=crop" },
  { id: 11, name: "Mexicana", price: 8.90, description: "Paradajková omáčka, mozzarella, pikantná saláma, fazuľa, kukurica, jalapeno", img: "https://images.unsplash.com/photo-1628840042765-356cda07504e?w=800&h=600&fit=crop" },
  { id: 12, name: "Funghi", price: 7.90, description: "Paradajková omáčka, mozzarella, rôzne druhy húb", img: "https://images.unsplash.com/photo-1571407970349-bc81e7e96d47?w=800&h=600&fit=crop" }
];

export default function PizzaDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [selectedExtras, setSelectedExtras] = useState<string[]>([]);
  const [added, setAdded] = useState(false);
  
  const pizza = PIZZAS.find(p => p.id === Number(id));
  
  const addToCart = useCartStore((state) => state.addItem);


  const groupedExtras = {
    "Zelenina": [],
    "Syr": [],
    "Mäso / Ryby": [],
    "Ostatné": []
  };

  pizzaExtras.forEach(extra => {
    const name = extra.name.toLowerCase();
    if (/(cesnak|cibu|olivy|kapary|kapusta|kukurica|brokolica|fazu|paradajk|baranie|jalape|arti|šparg|špenát|rukola)/.test(name)) {
      groupedExtras["Zelenina"].push(extra);
    } else if (/(gorgonzola|parmez|bryndza|niva|enci|mozzarella|syr)/.test(name)) {
      groupedExtras["Syr"].push(extra);
    } else if (/(kuracie|hov|tuniak|losos|krevety|šunka|saláma|slanina|klobása|tirolská|pancetta)/.test(name)) {
      groupedExtras["Mäso / Ryby"].push(extra);
    } else {
      groupedExtras["Ostatné"].push(extra);
    }
  });


  if (!pizza) {
    return (
      <div className="pt-20 px-4 text-center">
        <h1 className="text-2xl font-bold">Pizza nebola nájdená</h1>
        <Link to="/menu" className="text-[#6BA368] hover:underline">
          Späť na menu
        </Link>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart({
      id: pizza.id,
      name: pizza.name,
      price: pizza.price + selectedExtras.length * 1.0,
      quantity: 1,
      image: pizza.img,
      extras: selectedExtras,
    });
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
    navigate('/checkout');
  };

  
  const selectedExtraTotal = pizzaExtras
    .filter(extra => selectedExtras.includes(extra.name))
    .reduce((sum, e) => sum + e.price, 0);

  const totalPrice = (pizza.price + selectedExtraTotal).toFixed(2);


const toggleExtra = (extra: string) => {
    setSelectedExtras(prev =>
      prev.includes(extra)
        ? prev.filter(e => e !== extra)
        : [...prev, extra]
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-20 pb-12 px-4">
      <div className="max-w-4xl mx-auto">
        <button
          onClick={() => navigate(-1)}
          className="mb-6 flex items-center text-gray-600 hover:text-[#6BA368] transition-colors"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Späť
        </button>
{added && <span className="ml-4 text-green-600 text-sm">✔ Pridané do košíka</span>}
        
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="md:flex">
            <div className="md:w-1/2">
              <img
                src={pizza.img}
                alt={pizza.name}
                loading="lazy" className="w-full h-64 md:h-full object-cover transition-transform duration-300 hover:scale-105 transform transition-transform duration-150 active:scale-95"
              />
            </div>
            <div className="md:w-1/2 p-6 md:p-8">
              <h1 className="text-3xl font-bold mb-2">{pizza.name}</h1>
              <p className="text-gray-600 mb-6">{pizza.description}</p>
              
              <div className="mb-6">
                <h2 className="text-xl font-semibold mb-4">Extra prílohy:</h2>
{Object.entries(groupedExtras).map(([group, items]) => (
  <div key={group} className="mb-4">
    <h3 className="text-md font-semibold text-[#6BA368] mb-2">{group}</h3>
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {items.map((extra) => (
        <label key={extra.name} className={`flex items-center space-x-3 p-3 rounded-lg border cursor-pointer transition-colors ${selectedExtras.includes(extra.name) ? "bg-[#f0fdf4] border-[#6BA368]" : "hover:bg-gray-50"}`}>
          <input
            type="checkbox"
            checked={selectedExtras.includes(extra.name)}
            onChange={() => toggleExtra(extra.name)}
            className="rounded text-[#6BA368] focus:ring-[#6BA368]"
          />
          <span className="flex-1">{extra.name}</span>
          <span className="text-gray-500">+{extra.price.toFixed(2)}€</span>
        </label>
      ))}
    </div>
  </div>
))}
                  {AVAILABLE_EXTRAS.map((extra) => (
                    <label
                      key={extra.id}
                      className={`flex items-center space-x-3 p-3 rounded-lg border cursor-pointer transition-colors ${selectedExtras.includes(extra.name) ? "bg-[#f0fdf4] border-[#6BA368]" : "hover:bg-gray-50"}`}
                    >
                      <input
                        type="checkbox"
                        checked={selectedExtras.includes(extra.name)}
                        onChange={() => toggleExtra(extra.name)}
                        className="rounded text-[#6BA368] focus:ring-[#6BA368]"
                      />
                      <span className="flex-1">{extra.name}</span>
                      <span className="text-gray-500">+{extra.price}€</span>
                    </label>
                  ))}
                </div>
              </div>
              
              <div className="flex items-center justify-between mt-8">
                <div className="text-3xl font-bold text-[#6BA368]">
                  {totalPrice}€
                </div>
                <button
                  onClick={handleAddToCart}
                  className="bg-[#6BA368] text-white px-8 py-3 rounded-xl font-semibold hover:bg-[#5a915a] transition-transform duration-200 hover:scale-105 transform transition-transform duration-150 active:scale-95"
                >
                  Pridať do košíka
                </button>
{added && <span className="ml-4 text-green-600 text-sm">✔ Pridané do košíka</span>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
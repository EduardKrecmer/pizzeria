
import { useNavigate } from "react-router-dom";
import { pizzaMenu } from "../data/pizzaMenu";
import { pizzaExtras } from "../data/pizzaExtras";

export default function Home() {
  const navigate = useNavigate();

  const now = new Date();
  const bratislavaTime = new Date(
    now.toLocaleString('en-US', { timeZone: 'Europe/Bratislava' })
  );
  const day = bratislavaTime.getDay(); // 0 = Nedeľa, 1 = Pondelok, ..., 6 = Sobota
  const hour = bratislavaTime.getHours();
  const isOpen = (day >= 2 && day <= 6) && (hour >= 15 && hour < 22);


  return (
    <div className="pt-20 px-4 pb-12 max-w-6xl mx-auto">
      
      <div className={`mb-4 px-4 py-2 rounded-xl text-sm font-medium w-fit ${
        isOpen ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-700'
      }`}>
        {isOpen ? '🟢 Máme otvorené – objednaj si svoju obľúbenú pizzu!' : '🔴 Momentálne máme zatvorené'}
      </div>

      <h1 className="text-3xl font-bold mb-6 text-[#6BA368]">Vyber si pizzu</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {pizzaMenu.map((pizza) => (
          <div
            key={pizza.id}
            className="bg-white rounded-xl shadow hover:shadow-lg transition cursor-pointer"
            onClick={() => navigate(`/pizza/${pizza.id}`)}
          >
            <div className="aspect-w-4 aspect-h-3 overflow-hidden rounded-t-xl">
              <img
                src={pizza.image || 'https://via.placeholder.com/400x300?text=Pizza'}
                alt={pizza.name}
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </div>
            <div className="p-4">
              <h2 className="text-xl font-semibold">{pizza.name}</h2>
              <p className="text-sm text-gray-500 mb-2">{pizza.ingredients}</p>
              <div className="text-[#6BA368] font-bold text-lg">{pizza.price} €</div>
            </div>
          </div>
        ))}
      </div>

      <h2 className="text-2xl font-bold mt-12 mb-4 text-[#6BA368]">Extra prílohy</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {pizzaExtras.map((extra, idx) => (
          <div
            key={idx}
            className="p-3 border rounded-lg bg-white shadow-sm text-sm flex justify-between"
          >
            <span>{extra.name}</span>
            <span className="font-medium text-[#6BA368]">{extra.price.toFixed(2)} €</span>
          </div>
        ))}
      </div>
    </div>
  );
}

import { create } from 'zustand';

export interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  image: string;
  extras: string[];
}

interface CartStore {
  items: CartItem[];
  addItem: (item: CartItem) => void;
  removeItem: (id: number) => void;
  clearCart: () => void;
  updateQuantity: (id: number, quantity: number) => void;
  addExtra: (itemId: number, extra: string) => void;
  removeExtra: (itemId: number, extra: string) => void;
}

export const useCartStore = create<CartStore>((set) => ({
  items: [],
  addItem: (item) =>
    set((state) => {
      const existingItem = state.items.find((i) => i.id === item.id);
      if (existingItem) {
        return {
          items: state.items.map((i) =>
            i.id === item.id
              ? { ...i, quantity: i.quantity + 1 }
              : i
          ),
        };
      }
      return { items: [...state.items, { ...item, quantity: 1 }] };
    }),
  removeItem: (id) =>
    set((state) => ({
      items: state.items.filter((i) => i.id !== id),
    })),
  clearCart: () => set({ items: [] }),
  updateQuantity: (id, quantity) =>
    set((state) => ({
      items: state.items.map((i) =>
        i.id === id ? { ...i, quantity } : i
      ),
    })),
  addExtra: (itemId, extra) =>
    set((state) => ({
      items: state.items.map((i) =>
        i.id === itemId
          ? { ...i, extras: [...i.extras, extra] }
          : i
      ),
    })),
  removeExtra: (itemId, extra) =>
    set((state) => ({
      items: state.items.map((i) =>
        i.id === itemId
          ? { ...i, extras: i.extras.filter((e) => e !== extra) }
          : i
      ),
    })),
}));
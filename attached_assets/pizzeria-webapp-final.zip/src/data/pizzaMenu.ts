export const pizzaMenu = [
  {
    "id": 1,
    "name": "SYROVÁ",
    "weight": "",
    "ingredients": "paradajkové drt, bazalka, mozzarella",
    "price": "5.10"
  },
  {
    "id": 2,
    "name": "ŠUNKOVÁ",
    "weight": "",
    "ingredients": "paradajkova drt, bazalka , mozzarella, Sunka",
    "price": "6.10"
  },
  {
    "id": 3,
    "name": "ŠUNKOVO-ŠAMPIŇÓNOVÁ",
    "weight": "",
    "ingredients": "paradajkova drt,bazalka, mozzarella, Sunka, Sampliiény",
    "price": "6.70"
  },
  {
    "id": 4,
    "name": "ŠTYRI ROČNÉ OBDOBIA",
    "weight": "",
    "ingredients": "paradaj. drt, bazalka, mozzar., Sunka Sampifény, arti¢oky, olivy",
    "price": "7.00"
  },
  {
    "id": 5,
    "name": "VAJÍČKOVÁ",
    "weight": "",
    "ingredients": "paradajkova drt, bazalka, mozzarella, Sunka, Sampifiény, vaji¢ko",
    "price": "7.20"
  },
  {
    "id": 6,
    "name": "ANANÁSOVÁ",
    "weight": "",
    "ingredients": "paradajkové drt, bazalka, mozzarella, Sunka, anands",
    "price": "7.00"
  },
  {
    "id": 7,
    "name": "KUKURIČNÁ",
    "weight": "",
    "ingredients": "paradajkova drt, bazalka, mozzarella, Sunka, kukurica",
    "price": "6.70"
  },
  {
    "id": 8,
    "name": "KLASICKÁ",
    "weight": "",
    "ingredients": "paradajkovd drt, bazalka, mozzar., Sunka, Sampitiény, kukurica",
    "price": "7.00"
  },
  {
    "id": 9,
    "name": "ŠAMPIŇÓNOVÁ",
    "weight": "",
    "ingredients": "par.drt, bazalka, mozzar., gorgonzola, niva, deny syr, Spargla",
    "price": "6.00"
  },
  {
    "id": 10,
    "name": "ŠTYRI DRUHY SYRA",
    "weight": "",
    "ingredients": "parada.drt, bazalka, mozzarella z byvolieho mlieka, tierne olivy",
    "price": "7.50"
  },
  {
    "id": 11,
    "name": "BYVOLIA",
    "weight": "",
    "ingredients": "paradajkova drt, bazalka, mozzarella, slanina, cibuta",
    "price": "6.80"
  },
  {
    "id": 12,
    "name": "SLANINOVÁ",
    "weight": "",
    "ingredients": "paradajkové drt, bazalka, mozzarella, saléma, olivy, cibula",
    "price": "7.20"
  },
  {
    "id": 13,
    "name": "SALÁMOVÁ",
    "weight": "",
    "ingredients": "paradaj.drt, bazaika, mozzar., Stipfava Saléma, chilli, éierne olivy",
    "price": "7.20"
  },
  {
    "id": 14,
    "name": "OHNIVÁ",
    "weight": "",
    "ingredients": "paradajkova drt, bazalka; mozzarella, tirolska stanina, cibufa, olivy",
    "price": "7.50"
  },
  {
    "id": 15,
    "name": "TIROLSKÁ",
    "weight": "",
    "ingredients": "parada.drt, bazaika, mazzar, Sunk sanina, aléma, kysié kapusta",
    "price": "7.30"
  },
  {
    "id": 16,
    "name": "GAZDOVSKÁ",
    "weight": "",
    "ingredients": "paradajkové drt, bazalka, mozzarella, kuracie prsia, kukurica,niva",
    "price": "7.50"
  },
  {
    "id": 17,
    "name": "FURMANSKÁ",
    "weight": "",
    "ingredients": "paradajkové drt, bazalka, mozzarella, tunlak, olivy, cibula",
    "price": "7.70"
  },
  {
    "id": 18,
    "name": "KURACIA",
    "weight": "",
    "ingredients": "paradajkova drt, bazalka, mozzarella, lasos, olivy",
    "price": "7.70"
  },
  {
    "id": 19,
    "name": "BRUSNICOVÁ",
    "weight": "",
    "ingredients": "parada. drt, bazalka, mozzar., brokolica, kukurica, kyslé smotana",
    "price": "7.50"
  },
  {
    "id": 20,
    "name": "TUNIAKOVÁ",
    "weight": "",
    "ingredients": "paradajkové dt, bazaka, mozzarella, cherry paradajby, parmezdn",
    "price": "7.20"
  },
  {
    "id": 21,
    "name": "LOSOSOVÁ",
    "weight": "",
    "ingredients": "olivovy ole}, mozzarella, cesnak",
    "price": "7.20"
  },
  {
    "id": 22,
    "name": "BROKOLICOVÁ",
    "weight": "",
    "ingredients": "olivovy ole}, mozzarella, cesnak, slanina, niva",
    "price": "7.00"
  },
  {
    "id": 23,
    "name": "PARADAJKOVÁ",
    "weight": "",
    "ingredients": "paradajkové drt, bazalka, mozzarella, Spendt, piniové oriesky",
    "price": "6.70"
  },
  {
    "id": 24,
    "name": "POSÚCH",
    "weight": "",
    "ingredients": "paradaj. drt, bazalka, mozzar., sus. hov. svieckova, parmezan, rukola",
    "price": "5.10"
  },
  {
    "id": 25,
    "name": "SLANINOVÝ POSÚCH",
    "weight": "",
    "ingredients": "paradajkové drt, bazalka, mozzarella, krevety, cesnak",
    "price": "6.50"
  },
  {
    "id": 26,
    "name": "ŠPENÁTOVÁ",
    "weight": "",
    "ingredients": "paradajkovd drt, bazalka , mozzarella, pancetta, kapary",
    "price": "6.80"
  },
  {
    "id": 27,
    "name": "JANÍČKOVA",
    "weight": "",
    "ingredients": "ricotta, kuracie prsia, cherry paradajky, rukola",
    "price": "8.40"
  },
  {
    "id": 28,
    "name": "KREKETOVÁ",
    "weight": "",
    "ingredients": "paradaj. drt, bazalka, mozzar., klobdsa, fazufa, bar. rahy, cibuta, rukola",
    "price": "7.20"
  },
  {
    "id": 29,
    "name": "TALIANSKA",
    "weight": "",
    "ingredients": "smotanovy zaklad, bryndza, slanina",
    "price": "7.50"
  },
  {
    "id": 30,
    "name": "FITNESS",
    "weight": "450g",
    "ingredients": "paradajkový základ, mozzarella, špenát, cesnak",
    "price": "7.50"
  },
  {
    "id": 31,
    "name": "MEXICKÁ",
    "weight": "450g",
    "ingredients": "paradajkový základ, mozzarella, fazuľa, feferónky, kukurica",
    "price": "7.50"
  },
  {
    "id": 32,
    "name": "BRYNDZOVÁ",
    "weight": "500g",
    "ingredients": "smotanový základ, bryndza, slanina",
    "price": "8.00"
  }
];
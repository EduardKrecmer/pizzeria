export const pizzaExtras = [
  {
    "name": "Cesnak 5g",
    "price": 0.2
  },
  {
    "name": "Chilli 5g",
    "price": 0.5
  },
  {
    "name": "Sladké chilli 5g",
    "price": 0.5
  },
  {
    "name": "Cibuľa 15g",
    "price": 0.2
  },
  {
    "name": "Olivy 30g",
    "price": 0.5
  },
  {
    "name": "Kapary 30g",
    "price": 0.8
  },
  {
    "name": "Kapusta 30g",
    "price": 0.7
  },
  {
    "name": "Piniové oriešky 10g",
    "price": 0.8
  },
  {
    "name": "Vajíčko 1 ks",
    "price": 0.5
  },
  {
    "name": "Šampiňóny 50g",
    "price": 0.5
  },
  {
    "name": "Kukurica 50g",
    "price": 0.5
  },
  {
    "name": "Cherry paradajky 50g",
    "price": 0.5
  },
  {
    "name": "Baranie rohy 50g",
    "price": 0.5
  },
  {
    "name": "Jalapeño 50g",
    "price": 0.5
  },
  {
    "name": "Artičoky 30g",
    "price": 0.7
  },
  {
    "name": "Špargľa 30g",
    "price": 0.7
  },
  {
    "name": "Špenát 30g",
    "price": 0.7
  },
  {
    "name": "Rukola 30g",
    "price": 0.7
  },
  {
    "name": "Ananás 50g",
    "price": 0.5
  },
  {
    "name": "Brokolica 50g",
    "price": 0.5
  },
  {
    "name": "Fazuľa 50g",
    "price": 0.5
  },
  {
    "name": "Gorgonzola 50g",
    "price": 1.0
  },
  {
    "name": "Parmezán 50g",
    "price": 1.0
  },
  {
    "name": "Bryndza 50g",
    "price": 1.0
  },
  {
    "name": "Niva 50g",
    "price": 0.7
  },
  {
    "name": "Encián 50g",
    "price": 0.7
  },
  {
    "name": "Byvolia mozzarella 50g",
    "price": 1.2
  },
  {
    "name": "Kuracie mäso 80g",
    "price": 1.5
  },
  {
    "name": "Hovädzia sviečková 50g",
    "price": 2.0
  },
  {
    "name": "Tuniak 50g",
    "price": 1.2
  },
  {
    "name": "Losos 50g",
    "price": 1.8
  },
  {
    "name": "Krevety 50g",
    "price": 2.5
  },
  {
    "name": "Šunka 50g",
    "price": 1.0
  },
  {
    "name": "Saláma 50g",
    "price": 1.0
  },
  {
    "name": "Štipľavá saláma 50g",
    "price": 1.0
  },
  {
    "name": "Slanina 50g",
    "price": 1.2
  },
  {
    "name": "Klobása 50g",
    "price": 1.2
  },
  {
    "name": "Tirolská slanina 50g",
    "price": 1.2
  },
  {
    "name": "Pancetta 50g",
    "price": 1.2
  }
];